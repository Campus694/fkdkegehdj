package com.example.paymenthelper

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Reads the balance shown in the bank's home-screen widget after the user taps its refresh button.
 *
 * Flow: a tap on a view in the launcher (or in the bank app) arms the reader for a short window.
 * While armed, visible text of the launcher / bank window is scanned for a balance and stored.
 * Nothing is clicked or opened; the service only observes events and reads text.
 *
 * The service keeps no one-shot "returned" latch, so it works on every tap without being
 * toggled off and on in Android settings.
 */
class BankAccessibilityService : AccessibilityService() {

    companion object {
        private const val PREFS = "payment_helper"
        private const val ARM_WINDOW_MS = 20_000L   // how long after a tap we keep listening
        private const val STALE_GUARD_MS = 5_000L
        private const val LOGIN_WINDOW_MS = 120_000L

        @Volatile private var armedAt: Long = 0L
        @Volatile private var homePackages: Set<String> = emptySet()
        @Volatile private var loginStartedAt: Long = 0L
        @Volatile private var loginPackage: String? = null
        @Volatile private var loginFinished: Boolean = false

        fun beginCheck(context: Context, packageName: String) {
            armedAt = SystemClock.elapsedRealtime()
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString("check_package", packageName)
                .putLong("check_started_at", System.currentTimeMillis()).apply()
        }

        fun beginLoginCheck(context: Context, packageName: String) {
            loginStartedAt = SystemClock.elapsedRealtime()
            loginPackage = packageName
            loginFinished = false
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("login_package", packageName)
                .putLong("login_started_at", System.currentTimeMillis())
                .putLong("login_result_time", 0L)
                .apply()
        }
    }

    private data class Reading(val balance: String, val dateText: String?) {
        val key: String get() = "$balance|${dateText.orEmpty()}"
    }

    private val labelRegex = Regex("(?i)баланс|доступно|остаток|available|balance")
    private val dateRegex = Regex("\\d{2}\\.\\d{2}\\.\\d{4}\\s+\\d{2}:\\d{2}")
    private val amountRegex = Regex("\\d(?:[\\d\\s\\u00A0'.,]*\\d)?")
    private val currencyRegex = Regex("(?i)₽|руб\\.?|BYN|RUB|USD|EUR|€|\\$|бел\\.\\s*руб\\.?")
    private val amountWithCurrencyRegex = Regex("(?i)^($amountRegex)\\s*($currencyRegex)$")
    private val labelAmountRegex = Regex("(?i)(?:баланс|доступно|остаток|available|balance)\\D{0,20}?($amountRegex)\\s*($currencyRegex)?")

    override fun onServiceConnected() {
        super.onServiceConnected()
        @Suppress("DEPRECATION")
        homePackages = packageManager
            .queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_ALL)
            .mapNotNull { it.activityInfo?.packageName }
            .toSet()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val source = event.packageName?.toString() ?: return
        val bank = bankPackage()
        val now = SystemClock.elapsedRealtime()

        // Login flow: observe only the selected app's visible screen. Never read or fill credentials.
        if (!loginFinished && loginPackage == source && loginStartedAt > 0L) {
            if (now - loginStartedAt > LOGIN_WINDOW_MS) {
                loginStartedAt = 0L
                loginPackage = null
            } else if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
                val loginRoot = rootInActiveWindow
                if (loginRoot != null) {
                    val screenTexts = mutableListOf<String>()
                    collectVisibleText(loginRoot, screenTexts, 0)
                    if (looksLikeLoggedInHome(screenTexts)) {
                        loginFinished = true
                        loginStartedAt = 0L
                        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        prefs.edit().putString("login_result", "Красава, похоже, вход выполнен!")
                            .putLong("login_result_time", System.currentTimeMillis()).apply()
                        val back = packageManager.getLaunchIntentForPackage(packageName)
                        if (back != null) {
                            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            startActivity(back)
                        }
                        return
                    }
                }
            }
        }

        // A tap on the refresh button (home-screen widget or bank app) arms the reader.
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            if (source in homePackages || source == bank) armedAt = now
            return
        }

        val armed = armedAt
        if (armed == 0L) return
        if (now - armed > ARM_WINDOW_MS) {
            armedAt = 0L
            return
        }
        if (source !in homePackages && source != bank) return

        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        collectVisibleText(root, texts, 0)
        val reading = extractReading(texts) ?: return

        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        // Ignore the old value shown right after the tap, unless the balance/date changed.
        if (reading.key == prefs.getString("last_key", null) && now - armed < STALE_GUARD_MS) return

        prefs.edit()
            .putString("last_key", reading.key)
            .putString("last_balance", reading.balance)
            .putString("last_balance_date", reading.dateText)
            .putLong("last_balance_time", System.currentTimeMillis())
            .apply()
        armedAt = 0L
    }


    private fun looksLikeLoggedInHome(texts: List<String>): Boolean {
        val all = texts.joinToString(" ").lowercase()
        val loginWords = listOf("введите пароль", "код доступа", "войти", "логин", "пароль", "sign in", "log in", "passcode")
        if (loginWords.any { it in all }) return false
        val homeWords = listOf("карты", "счета", "переводы", "платежи", "история операций", "баланс", "accounts", "cards", "transfers", "payments")
        return homeWords.count { it in all } >= 2
    }

    private fun bankPackage(): String? {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString("check_package", null) ?: prefs.getString("selected_package", null)
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size > 500) return
        if (node.isVisibleToUser) {
            node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        }
        for (i in 0 until node.childCount) collectVisibleText(node.getChild(i), out, depth + 1)
    }

    /**
     * The widget may give the amount as one node ("0.57 BYN") or as several nodes ("Карта 1", "0.57", "BYN").
     * Labelled amounts win; otherwise the first amount followed by a currency is used.
     * Plain numbers without a currency are never accepted (e.g. "#5083" or "Карта 1").
     */
    private fun extractReading(texts: List<String>): Reading? {
        val dateText = dateRegex.find(texts.joinToString(" | "))?.value
        var fallback: String? = null

        for (i in texts.indices) {
            val text = texts[i]

            labelAmountRegex.find(text)?.let { m ->
                val amount = m.groupValues[1]
                val currency = m.groupValues[2]
                return Reading(clean(if (currency.isEmpty()) amount else "$amount $currency"), dateText)
            }

            amountWithCurrencyRegex.find(text)?.let { m ->
                val candidate = clean("${m.groupValues[1]} ${m.groupValues[2]}")
                if (hasLabelBefore(texts, i)) return Reading(candidate, dateText)
                if (fallback == null) fallback = candidate
            }

            if (amountRegex.matches(text) && i + 1 < texts.size && currencyRegex.matches(texts[i + 1])) {
                val candidate = clean("$text ${texts[i + 1]}")
                if (hasLabelBefore(texts, i)) return Reading(candidate, dateText)
                if (fallback == null) fallback = candidate
            }
        }
        return fallback?.let { Reading(it, dateText) }
    }

    private fun hasLabelBefore(texts: List<String>, index: Int): Boolean =
        (maxOf(0, index - 3) until index).any { labelRegex.containsMatchIn(texts[it]) }

    private fun clean(s: String): String = s.replace(Regex("[\\s\\u00A0]+"), " ").trim()

    override fun onInterrupt() = Unit
}
