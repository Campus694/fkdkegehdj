package com.example.paymenthelper

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Automates a single login attempt in the selected bank app:
 * fills the stored password into the login field, taps the submit button,
 * then watches the screen for success (home screen) or an error message.
 *
 * Robustness notes (why it stopped "misbehaving" on the second run):
 * - onAccessibilityEvent does no heavy work; all periodic attempts are driven
 *   by a lightweight 1-second handler tick, so a flood of accessibility
 *   events (or their absence) can neither block the service nor stall the flow.
 * - Every callback body is wrapped in try/catch and logged; an uncaught
 *   exception inside an accessibility service is what makes Android show
 *   "service is not responding — turn it off and on".
 *
 * The login screen may take several seconds to appear; the tick keeps retrying
 * the fill step (every ~1 s) until the window expires, so a 5-second splash is
 * not a problem.
 */
class BankAccessibilityService : AccessibilityService() {

    companion object {
        private const val PREFS = "payment_helper"
        private const val LOGIN_WINDOW_MS = 120_000L
        private const val TICK_MS = 1_000L          // periodic retry interval
        private const val RESULT_GRACE_MS = 1_500L  // settle time after submit
        private const val MAX_DEPTH = 30

        @Volatile private var loginStartedAt: Long = 0L
        @Volatile private var loginPackage: String? = null
        @Volatile private var loginFinished: Boolean = false
        @Volatile private var submitPressedAt: Long = 0L
        @Volatile private var awaitingResult: Boolean = false
        @Volatile private var lastFillLog: String = ""

        fun beginLoginCheck(context: Context, packageName: String) {
            loginStartedAt = SystemClock.elapsedRealtime()
            loginPackage = packageName
            loginFinished = false
            submitPressedAt = 0L
            awaitingResult = false
            lastFillLog = ""
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("login_package", packageName)
                .putLong("login_started_at", System.currentTimeMillis())
                .putLong("login_result_time", 0L)
                .apply()
            DebugLog.log("SVC: beginLoginCheck пакет=$packageName")
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            try {
                onTick()
            } catch (e: Exception) {
                DebugLog.log("SVC: ОШИБКА в тике — ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                handler.postDelayed(this, TICK_MS)
            }
        }
    }

    private val loginScreenRegex = Regex("(?i)войти|пароль|логин|sign in|log in|passcode|password|введите")
    private val submitRegex = Regex("(?i)^\\s*(войти|вход|подтвердить|sign in|log in|login|далее|next)\\s*$")
    private val errorRegex = Regex(
        "(?i)неверн|неправильн|ошибк|не удалось войти|повторите попытку|заблокирован|incorrect|wrong password|invalid|try again"
    )
    private val homeWords = listOf(
        "карты", "счета", "переводы", "платежи", "история", "баланс",
        "профиль", "accounts", "cards", "transfers", "payments", "history"
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        DebugLog.log("SVC: служба подключена")
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        DebugLog.log("SVC: служба уничтожена")
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally minimal: the heavy lifting happens in onTick().
        // Logging only the essential bits to avoid log flooding from chatty apps.
        if (event == null || loginFinished || loginStartedAt == 0L) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            DebugLog.log("SVC: окно изменено, пакет=${event.packageName}")
        }
    }

    override fun onInterrupt() {
        DebugLog.log("SVC: onInterrupt")
    }

    /** Called every second; drives the whole fill → result state machine. */
    private fun onTick() {
        if (loginFinished || loginStartedAt == 0L) return
        val bank = loginPackage ?: return
        val now = SystemClock.elapsedRealtime()

        if (now - loginStartedAt > LOGIN_WINDOW_MS) {
            publishResult("Не удалось подтвердить вход автоматически ($lastFillLog). Вернитесь и попробуйте ещё раз.")
            return
        }

        val root = rootInActiveWindow ?: run {
            DebugLog.log("SVC: тик — активное окно недоступно")
            return
        }
        val pkg = root.packageName?.toString()
        if (pkg != bank) {
            // The bank is not in the foreground (splash of launcher etc.) — wait.
            DebugLog.log("SVC: тик — на переднем плане $pkg, ждём $bank")
            return
        }

        val texts = mutableListOf<String>()
        collectVisibleText(root, texts, 0)
        val screenText = texts.joinToString(" ")
        DebugLog.log("SVC: тик — экран: ${screenText.take(120)}")

        if (!awaitingResult) {
            if (!loginScreenRegex.containsMatchIn(screenText)) {
                lastFillLog = "экран входа не распознан"
                DebugLog.log("SVC: тик — экран входа пока не распознан")
                return
            }
            attemptFill(root)
        } else {
            if (now - submitPressedAt < RESULT_GRACE_MS) return
            when {
                looksLikeLoggedInHome(screenText) -> {
                    DebugLog.log("SVC: обнаружен главный экран — успех")
                    publishResult("Красава, вход выполнен!")
                }
                errorRegex.containsMatchIn(screenText) -> {
                    DebugLog.log("SVC: обнаружено сообщение об ошибке на экране")
                    publishResult("Вход не выполнен: приложение сообщило об ошибке (проверьте пароль).")
                }
                else -> DebugLog.log("SVC: тик — ждем результат входа…")
            }
        }
    }

    private var lastTreeDumpAt = 0L

    private fun attemptFill(root: AccessibilityNodeInfo) {
        val candidates = collectInputCandidates(root, 0)
        if (candidates.isEmpty()) {
            lastFillLog = "поле ввода не найдено"
            DebugLog.log("SVC: заполнение — полей ввода на экране не найдено")
            // Once every 5 seconds dump the whole visible tree so we can see
            // what the bank's login screen is actually made of.
            val now = SystemClock.elapsedRealtime()
            if (now - lastTreeDumpAt > 5_000L) {
                lastTreeDumpAt = now
                dumpTree(root, 0)
            }
            return
        }
        candidates.forEachIndexed { i, (node, reason) ->
            DebugLog.log("SVC: кандидат[$i] ($reason): class=${node.className} " +
                "editable=${node.isEditable} clickable=${node.isClickable} " +
                "hint=\"${node.hintText}\" text=\"${node.text?.take(20)}\"")
        }

        val password = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("login_password", "olga123") ?: "olga123"

        // Try candidates from last to first (the password field is usually the last one).
        for ((node, reason) in candidates.reversed()) {
            DebugLog.log("SVC: пробуем заполнить кандидата ($reason)…")
            if (fillNode(root, node, password)) {
                val button = findSubmitButton(root, 0)
                if (button == null) {
                    lastFillLog = "кнопка «Войти» не найдена"
                    DebugLog.log("SVC: кнопка «Войти» не найдена, тексты экрана: ${screenTextOf(root).take(200)}")
                    return
                }
                val clicked = button.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                DebugLog.log("SVC: нажатие кнопки → ACTION_CLICK=$clicked")
                if (clicked) {
                    awaitingResult = true
                    submitPressedAt = SystemClock.elapsedRealtime()
                    lastFillLog = "кнопка нажата"
                } else {
                    lastFillLog = "клик по кнопке не сработал"
                }
                return
            }
        }
        lastFillLog = "ни один кандидат не принял текст"
    }

    /** Fills a candidate using SET_TEXT → FOCUS+PASTE → tap+PASTE fallbacks. */
    private fun fillNode(root: AccessibilityNodeInfo, node: AccessibilityNodeInfo, password: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, password)
        }
        if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            DebugLog.log("SVC: ACTION_SET_TEXT выполнен успешно")
            return true
        }
        DebugLog.log("SVC: ACTION_SET_TEXT не сработал, пробуем FOCUS + ACTION_PASTE")

        // Clipboard may be blocked for background apps on Android 10+; still worth trying.
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as? android.content.ClipboardManager
        if (clipboard != null) {
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("ph", password))
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            if (node.performAction(AccessibilityNodeInfo.ACTION_PASTE)) {
                DebugLog.log("SVC: ACTION_PASTE выполнен успешно")
                return true
            }
            // Last resort: tap the field center with a gesture, then paste into
            // whatever becomes input-focused (handles custom/WebView fields).
            val rect = android.graphics.Rect()
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty && dispatchGesture(
                    android.accessibilityservice.GestureDescription.Builder()
                        .addStroke(
                            android.accessibilityservice.GestureDescription.StrokeDescription(
                                android.graphics.Path().apply {
                                    moveTo(rect.exactCenterX(), rect.exactCenterY())
                                }, 0L, 60L
                            )
                        ).build(), null, null
                )
            ) {
                DebugLog.log("SVC: тап по полю сделан, ждём фокус…")
                try { Thread.sleep(700) } catch (_: InterruptedException) {}
                val fresh = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                if (fresh != null && fresh.performAction(AccessibilityNodeInfo.ACTION_PASTE)) {
                    DebugLog.log("SVC: вставка в сфокусированное поле выполнена")
                    return true
                }
                DebugLog.log("SVC: вставка после тапа не удалась (findFocus=${fresh != null})")
            }
        }
        return false
    }

    /**
     * Finds anything that can plausibly accept the password. Belarusbank's
     * login field does not report isEditable, so candidates are collected by
     * several signatures and logged with the reason they matched.
     */
    private fun collectInputCandidates(node: AccessibilityNodeInfo?, depth: Int): List<Pair<AccessibilityNodeInfo, String>> {
        val out = mutableListOf<Pair<AccessibilityNodeInfo, String>>()
        collectCandidatesRec(node, depth, out)
        return out
    }

    private fun collectCandidatesRec(node: AccessibilityNodeInfo?, depth: Int, out: MutableList<Pair<AccessibilityNodeInfo, String>>) {
        if (node == null || depth > MAX_DEPTH || out.size > 10) return
        val cls = node.className?.toString().orEmpty()
        val hint = node.hintText?.toString().orEmpty()
        val text = node.text?.toString().orEmpty()
        val reason = when {
            node.isVisibleToUser && node.isEditable -> "isEditable"
            node.isVisibleToUser && hint.isNotEmpty() -> "hint"
            node.isVisibleToUser && cls.contains("EditText", true) -> "class EditText"
            node.isVisibleToUser &&
                (hint.contains("введите", true) || text.contains("введите", true) ||
                    hint.contains("ключ", true) || text.contains("ключ", true)) -> "текст/подсказка «введите/ключ»"
            else -> null
        }
        if (reason != null) out.add(node to reason)
        for (i in 0 until node.childCount) {
            collectCandidatesRec(node.getChild(i), depth + 1, out)
        }
    }

    /** Bounded tree dump for diagnostics (class, flags, short text/hint per node). */
    private fun dumpTree(node: AccessibilityNodeInfo?, depth: Int) {
        if (node == null || depth > 12) return
        val indent = "  ".repeat(depth)
        val text = (node.text ?: node.hintText)?.toString()?.take(25).orEmpty()
        DebugLog.log(
            "TREE: $indent${node.className} " +
                "ed=${node.isEditable} clk=${node.isClickable} focus=${node.isFocusable} " +
                (if (text.isNotEmpty()) "\"$text\"" else "")
        )
        for (i in 0 until node.childCount) dumpTree(node.getChild(i), depth + 1)
    }

    private fun findSubmitButton(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > MAX_DEPTH) return null
        val label = node.text?.toString().orEmpty().ifEmpty {
            node.contentDescription?.toString().orEmpty()
        }
        if (label.isNotEmpty() && submitRegex.containsMatchIn(label)) {
            DebugLog.log("SVC: кандидат на кнопку: \"$label\" class=${node.className}")
            var current: AccessibilityNodeInfo? = node
            var hops = 0
            while (current != null && hops < 5) {
                if (current.isClickable) {
                    DebugLog.log("SVC: кликабельный предок найден (hops=$hops)")
                    return current
                }
                current = current.parent
                hops++
            }
            DebugLog.log("SVC: у кандидата \"$label\" нет кликабельных предков")
        }
        for (i in 0 until node.childCount) {
            findSubmitButton(node.getChild(i), depth + 1)?.let { return it }
        }
        return null
    }

    private fun looksLikeLoggedInHome(allText: String): Boolean {
        val all = allText.lowercase()
        if (loginScreenRegex.containsMatchIn(all)) return false
        val matched = homeWords.filter { it in all }
        if (matched.size >= 2) DebugLog.log("SVC: признаки главного экрана: $matched")
        return matched.size >= 2
    }

    private fun publishResult(message: String) {
        loginFinished = true
        loginStartedAt = 0L
        awaitingResult = false
        val pkg = loginPackage
        loginPackage = null
        DebugLog.log("SVC: итог — $message")
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("login_result", message)
            .putLong("login_result_time", System.currentTimeMillis())
            .apply()
        val back = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        if (back != null) {
            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(back)
            DebugLog.log("SVC: возврат в Payment Helper")
        } else {
            DebugLog.log("SVC: не удалось построить intent возврата")
        }
    }

    private fun screenTextOf(root: AccessibilityNodeInfo): String {
        val texts = mutableListOf<String>()
        collectVisibleText(root, texts, 0)
        return texts.joinToString(" ")
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size > 500) return
        if (node.isVisibleToUser) {
            node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        }
        for (i in 0 until node.childCount) collectVisibleText(node.getChild(i), out, depth + 1)
    }
}
