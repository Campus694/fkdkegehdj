package com.example.paymenthelper

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Automates a single login attempt in the selected bank app:
 * fills the stored password into the login field, taps the submit button,
 * then watches the screen for success (home screen) or an error message.
 *
 * Flow: MainActivity calls beginLoginCheck() before launching the bank app.
 * The service reacts only to events of the selected package during the
 * attempt window and publishes the result through prefs.
 *
 * Nothing is read or clicked outside an active attempt. Passwords are not
 * logged and stay in local prefs only.
 */
class BankAccessibilityService : AccessibilityService() {

    companion object {
        private const val PREFS = "payment_helper"
        private const val LOGIN_WINDOW_MS = 120_000L
        private const val RETRY_INTERVAL_MS = 800L
        private const val MAX_DEPTH = 30

        @Volatile private var loginStartedAt: Long = 0L
        @Volatile private var loginPackage: String? = null
        @Volatile private var loginFinished: Boolean = false
        @Volatile private var lastFillAttemptAt: Long = 0L
        @Volatile private var submitPressedAt: Long = 0L
        @Volatile private var awaitingResult: Boolean = false

        fun beginLoginCheck(context: Context, packageName: String) {
            loginStartedAt = SystemClock.elapsedRealtime()
            loginPackage = packageName
            loginFinished = false
            lastFillAttemptAt = 0L
            submitPressedAt = 0L
            awaitingResult = false
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("login_package", packageName)
                .putLong("login_started_at", System.currentTimeMillis())
                .putLong("login_result_time", 0L)
                .apply()
        }
    }

    private val loginScreenRegex = Regex("(?i)войти|пароль|логин|sign in|log in|passcode|password")
    private val homeWords = listOf(
        "карты", "счета", "переводы", "платежи", "история", "баланс",
        "профиль", "accounts", "cards", "transfers", "payments", "history"
    )
    private val errorRegex = Regex(
        "(?i)неверн|неправильн|ошибк|не удалось войти|повторите попытку|заблокирован|incorrect|wrong password|invalid|try again"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (loginFinished || loginStartedAt == 0L) return
        val source = event.packageName?.toString() ?: return
        val bank = loginPackage ?: return
        if (source != bank) return

        val now = SystemClock.elapsedRealtime()
        if (now - loginStartedAt > LOGIN_WINDOW_MS) {
            publishResult("Не удалось подтвердить вход автоматически. Вернитесь в Payment Helper и попробуйте ещё раз.")
            return
        }

        val interesting = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED
        if (!interesting) return

        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        collectVisibleText(root, texts, 0)
        val screenText = texts.joinToString(" ")

        if (!awaitingResult) {
            // Fill phase: wait for the login screen, type the password, press the button.
            if (now - lastFillAttemptAt < RETRY_INTERVAL_MS) return
            lastFillAttemptAt = now
            if (!loginScreenRegex.containsMatchIn(screenText)) return
            if (fillAndPassword(root)) {
                awaitingResult = true
                submitPressedAt = SystemClock.elapsedRealtime()
            }
        } else {
            // Result phase: give the app a moment after submit before judging the screen.
            if (now - submitPressedAt < 1_500L) return
            when {
                looksLikeLoggedInHome(screenText) ->
                    publishResult("Красава, вход выполнен!")
                errorRegex.containsMatchIn(screenText) ->
                    publishResult("Вход не выполнен: приложение сообщило об ошибке (проверьте пароль).")
            }
        }
    }

    /** Types the stored password into the first editable field and presses the submit button. */
    private fun fillAndPassword(root: AccessibilityNodeInfo): Boolean {
        val password = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("login_password", "olga123") ?: "olga123"
        val editable = findFirstEditable(root, 0)
        if (editable != null && !fillText(editable, password)) return false

        val button = findSubmitButton(root, 0) ?: return false
        return button.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun fillText(field: AccessibilityNodeInfo, value: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
        }
        if (field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true
        // Fallback: paste from clipboard if direct text set is not supported.
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as? android.content.ClipboardManager ?: return false
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("payment_helper", value))
        return field.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > MAX_DEPTH) return null
        if (node.isEditable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            findFirstEditable(node.getChild(i), depth + 1)?.let { return it }
        }
        return null
    }

    private fun findSubmitButton(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > MAX_DEPTH) return null
        val label = node.text?.toString().orEmpty().ifEmpty {
            node.contentDescription?.toString().orEmpty()
        }.trim().lowercase()
        if (label == "войти" || label == "вход" || label == "подтвердить" ||
            label == "sign in" || label == "log in" || label == "login" || label == "далее" || label == "next") {
            var current: AccessibilityNodeInfo? = node
            var hops = 0
            while (current != null && hops < 5) {
                if (current.isClickable) return current
                current = current.parent
                hops++
            }
        }
        for (i in 0 until node.childCount) {
            findSubmitButton(node.getChild(i), depth + 1)?.let { return it }
        }
        return null
    }

    private fun looksLikeLoggedInHome(allText: String): Boolean {
        val all = allText.lowercase()
        if (loginScreenRegex.containsMatchIn(all)) return false
        return homeWords.count { it in all } >= 2
    }

    private fun publishResult(message: String) {
        loginFinished = true
        loginStartedAt = 0L
        awaitingResult = false
        loginPackage = null
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("login_result", message)
            .putLong("login_result_time", System.currentTimeMillis())
            .apply()
        val back = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("login_package", null)?.let { pkg ->
                packageManager.getLaunchIntentForPackage(pkg)
            }
        if (back != null) {
            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(back)
        }
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size > 500) return
        if (node.isVisibleToUser) {
            node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        }
        for (i in 0 until node.childCount) collectVisibleText(node.getChild(i), out, depth + 1)
    }

    override fun onInterrupt() = Unit
}
