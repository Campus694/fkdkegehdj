package com.example.paymenthelper

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * PIN-code login automation for M-Belarusbank.
 *
 * LEARNING RUN: the user enters the PIN manually; every tap on a digit button
 * (node with a digit label) is recorded with its screen coordinates, in order.
 * When the logged-in home screen is detected, the sequence is saved.
 *
 * AUTO RUN: replays the saved digit taps one by one, then waits for the result.
 *
 * The PIN digits themselves are never stored — only tap coordinates.
 */
class BankAccessibilityService : AccessibilityService() {

    companion object {
        private const val PREFS = "payment_helper"
        private const val LOGIN_WINDOW_MS = 150_000L
        private const val TAP_INTERVAL_MS = 450L
        private const val PIN_LENGTH = 5
        private const val SETTLE_AFTER_LAST_TAP_MS = 1_000L

        @Volatile private var loginStartedAt: Long = 0L
        @Volatile private var loginPackage: String? = null
        @Volatile private var awaitingResult: Boolean = false
        @Volatile private var replayInFlight: Boolean = false
        private var learnMode: Boolean = true
        private var manualHintShown = false
        private var savedSteps: List<Pair<Float, Float>> = emptyList()

        fun beginLoginCheck(context: Context, packageName: String) {
            loginStartedAt = SystemClock.elapsedRealtime()
            loginPackage = packageName
            awaitingResult = false
            replayInFlight = false
            manualHintShown = false
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("login_package", packageName)
                .putLong("login_started_at", System.currentTimeMillis())
                .putLong("login_result_time", 0L)
            savedSteps = loadSteps(context)
            learnMode = savedSteps.isEmpty()
            prefs.apply()
            DebugLog.log(
                if (learnMode) "Первый запуск: введите пин-код вручную — запомню каждое нажатие."
                else "Ввожу пин-код автоматически (${savedSteps.size} нажатий)."
            )
        }

        private fun loadSteps(context: Context): List<Pair<Float, Float>> {
            val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString("pin_steps", null) ?: return emptyList()
            return raw.split(";").mapNotNull { pair ->
                val parts = pair.split(",")
                if (parts.size == 2) {
                    val x = parts[0].toFloatOrNull()
                    val y = parts[1].toFloatOrNull()
                    if (x != null && y != null) x to y else null
                } else null
            }
        }

        fun clearLearned(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove("pin_steps").apply()
            savedSteps = emptyList()
            learnMode = true
            DebugLog.log("Запомненный пин-код сброшен. Следующий вход — обучение.")
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            try { onTick() } catch (e: Exception) {
                DebugLog.log("Ошибка сервиса: ${e.message}")
            } finally {
                handler.postDelayed(this, 1_000L)
            }
        }
    }

    private val digitRegex = Regex("^\\d$")
    private val loginScreenRegex = Regex("(?i)пин|введите|ключ|войти|passcode|password")
    private val errorRegex = Regex(
        "(?i)неверн|неправильн|ошибк|не удалось войти|повторите попытку|заблокирован|incorrect|wrong|invalid|try again"
    )
    private val homeWords = listOf(
        "карты", "переводы", "платежи", "история", "баланс", "главная",
        "последние", "favorites", "payments", "history", "main"
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || loginStartedAt == 0L) return
        val bank = loginPackage ?: return
        if (event.packageName?.toString() != bank) return

        // Learning: record each tap on a digit button.
        if (learnMode && event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            val node = event.source
            val label = node?.text?.toString()?.trim().orEmpty()
            if (node != null && digitRegex.matches(label)) {
                val rect = android.graphics.Rect()
                node.getBoundsInScreen(rect)
                if (!rect.isEmpty) {
                    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    val current = prefs.getString("pin_draft", "") ?: ""
                    val updated = if (current.isEmpty()) "${rect.exactCenterX()},${rect.exactCenterY()}"
                        else "$current;${rect.exactCenterX()},${rect.exactCenterY()}"
                    prefs.edit().putString("pin_draft", updated).apply()
                    val count = updated.split(";").size
                    DebugLog.log("Запомнено нажатие №$count.")
                    if (count >= PIN_LENGTH) {
                        // All digits recorded — learning is done, no need to wait
                        // for the home screen: the user is logging in by themselves.
                        prefs.edit().putString("pin_steps", updated).remove("pin_draft").apply()
                        savedSteps = loadSteps(this)
                        learnMode = false
                        publishResult("Пин-код запомнен ($count нажатий). Дальше справлюсь сам!")
                    }
                }
            }
        }
    }

    override fun onInterrupt() = Unit

    private fun onTick() {
        if (loginStartedAt == 0L) return
        val bank = loginPackage ?: return
        val now = SystemClock.elapsedRealtime()

        if (now - loginStartedAt > LOGIN_WINDOW_MS) {
            publishResult("Время вышло, вход не подтверждён. Попробуйте ещё раз.")
            return
        }

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != bank) return

        val texts = mutableListOf<String>()
        collectVisibleText(root, texts, 0)
        val screenText = texts.joinToString(" ")

        if (awaitingResult) {
            when {
                looksLikeLoggedInHome(screenText) -> publishResult("Красава, вход выполнен!")
                errorRegex.containsMatchIn(screenText) ->
                    publishResult("Вход не выполнен: банк сообщил об ошибке. Проверьте пин-код.")
            }
            return
        }

        if (learnMode) {
            if (!manualHintShown) {
                manualHintShown = true
                DebugLog.log("Жду ваш пин-код: просто введите его на клавиатуре банка.")
            }
        } else if (!replayInFlight) {
            replayPin()
        }
    }

    /** AUTO RUN: wait a bit after launch, then tap every remembered digit in order. */
    private fun replayPin() {
        if (savedSteps.isEmpty()) return
        replayInFlight = true
        DebugLog.log("Начинаю ввод пин-кода через 7 секунд…")
        val startDelayMs = 7_000L
        savedSteps.forEachIndexed { index, (x, y) ->
            handler.postDelayed({
                DebugLog.log("Нажимаю цифру ${index + 1} из ${savedSteps.size}…")
                tapAt(x, y) { }
            }, startDelayMs + index * TAP_INTERVAL_MS)
        }
        handler.postDelayed({
            awaitingResult = true
            replayInFlight = false
        }, startDelayMs + savedSteps.size * TAP_INTERVAL_MS + SETTLE_AFTER_LAST_TAP_MS)
    }

    private fun tapAt(x: Float, y: Float, callback: (Boolean) -> Unit) {
        val path = android.graphics.Path().apply { moveTo(x, y) }
        val gesture = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0L, 60L))
            .build()
        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: android.accessibilityservice.GestureDescription?) = callback(true)
            override fun onCancelled(g: android.accessibilityservice.GestureDescription?) {
                DebugLog.log("Нажатие отменено системой.")
                callback(false)
            }
        }, null)
        if (!dispatched) callback(false)
    }

    private fun looksLikeLoggedInHome(allText: String): Boolean {
        val all = allText.lowercase()
        if (loginScreenRegex.containsMatchIn(all)) return false
        return homeWords.count { it in all } >= 2
    }

    private fun publishResult(message: String) {
        loginStartedAt = 0L
        awaitingResult = false
        loginPackage = null
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("pin_draft").apply()
        DebugLog.log(message)
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit()
            .putString("login_result", message)
            .putLong("login_result_time", System.currentTimeMillis())
            .apply()
        val back = prefs.getString("login_package", null)?.let { packageManager.getLaunchIntentForPackage(it) }
        if (back != null) {
            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(back)
        }
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size > 500) return
        if (node.isVisibleToUser) {
            node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        }
        for (i in 0 until node.childCount) collectVisibleText(node.getChild(i), out, depth + 1)
    }
}
