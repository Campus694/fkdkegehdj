package com.example.paymenthelper

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Floating panel (overlay) over any app + automation:
 * 1) pin learning with on-panel counter (1..5),
 * 2) refresh-button learning (next tap),
 * 3) auto run: open bank -> tap pin -> tap refresh -> read balance
 *    (a11y text first, then screenshot + ML Kit OCR; Android 11+).
 */
class BankAccessibilityService : AccessibilityService() {

    companion object {
        private const val PREFS = "payment_helper"
        private const val LOGIN_WINDOW_MS = 150_000L
        private const val TAP_INTERVAL_MS = 450L
        private const val PIN_LENGTH = 5
        private const val SETTLE_AFTER_LAST_TAP_MS = 1_000L
        private const val BALANCE_SETTLE_BEFORE_TAP_MS = 3_000L
        private const val BALANCE_READ_AFTER_TAP_MS = 3_500L
        private const val BALANCE_TIMEOUT_MS = 45_000L
        private const val AUTO_OPEN_DELAY_MS = 6_000L

        @Volatile var instance: BankAccessibilityService? = null
            private set

        // --- PIN login state (old "Перейти" flow, kept) ---
        @Volatile private var loginStartedAt: Long = 0L
        @Volatile private var loginPackage: String? = null
        @Volatile private var awaitingResult: Boolean = false
        @Volatile private var replayInFlight: Boolean = false
        private var learnMode: Boolean = true
        private var manualHintShown = false
        private var savedSteps: List<Pair<Float, Float>> = emptyList()

        // --- Panel state ---
        @Volatile private var autoRunning = false

        fun beginLoginCheck(context: Context, packageName: String) {
            loginStartedAt = SystemClock.elapsedRealtime()
            loginPackage = packageName
            awaitingResult = false
            replayInFlight = false
            manualHintShown = false
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("login_package", packageName)
                .putLong("login_started_at", System.currentTimeMillis())
                .putLong("login_result_time", 0L)
            savedSteps = loadSteps(context)
            learnMode = savedSteps.isEmpty()
            prefs.apply()
            DebugLog.log(
                if (learnMode) "Первый запуск: введите пин-код вручную — запомню каждое нажатие."
                else "Ввожу пин-код автоматически (${savedSteps.size} нажатий)."
            )
        }

        private fun loadSteps(context: Context): List<Pair<Float, Float>> {
            val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString("pin_steps", null) ?: return emptyList()
            return raw.split(";").mapNotNull { pair ->
                val parts = pair.split(",")
                if (parts.size == 2) {
                    val x = parts[0].toFloatOrNull()
                    val y = parts[1].toFloatOrNull()
                    if (x != null && y != null) x to y else null
                } else null
            }
        }

        fun clearLearned(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove("pin_steps").apply()
            savedSteps = emptyList()
            learnMode = true
            DebugLog.log("Запомненный пин-код сброшен. Следующий вход — обучение.")
        }

        fun isRefreshLearned(context: Context): Boolean =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains("refresh_x")

        fun clearRefresh(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove("refresh_x").remove("refresh_y").apply()
            DebugLog.log("Кнопка обновления сброшена.")
        }

        /** Old flow bridge: opens the panel and starts the auto run. */
        fun beginBalanceCheck(context: Context, packageName: String) {
            if (!isRefreshLearned(context)) {
                DebugLog.log("Сначала настройте кнопку обновления (кнопка «Настроить»).")
                return
            }
            DebugLog.log("Проверяю баланс: открываю банк и нажимаю обновление…")
            instance?.autoRun()
        }

        private fun publishBalance(context: Context, message: String, balance: String?) {
            DebugLog.log(message)
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("balance_result", message)
                .putString("last_balance", balance)
                .putLong("balance_result_time", System.currentTimeMillis())
                .apply()
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            try { onTick() } catch (e: Exception) {
                DebugLog.log("Ошибка сервиса: ${e.message}")
            } finally {
                handler.postDelayed(this, 1_000L)
            }
        }
    }

    // ================= Panel =================

    private enum class PanelMode { NONE, LEARN_PIN, LEARN_REFRESH }

    private var panelMode = PanelMode.NONE
    private var panelView: View? = null
    private var panelStatus: TextView? = null
    private var panelLogsView: TextView? = null
    private var pinDraft = StringBuilder()
    private var pinCount = 0

    private val panelLines = ArrayDeque<String>()
    private val digitRegex = Regex("^\\d$")
    private val loginScreenRegex = Regex("(?i)пин|введите|ключ|войти|passcode|password")
    private val errorRegex = Regex(
        "(?i)неверн|неправильн|ошибк|не удалось войти|повторите попытку|заблокирован|incorrect|wrong|invalid|try again"
    )
    private val homeWords = listOf(
        "карты", "переводы", "платежи", "история", "баланс", "главная",
        "последние", "favorites", "payments", "history", "main"
    )
    private val amountRegex = Regex("\\d+(?:[\\d\\s\\u00A0'.,]*\\d)?")
    private val currencyRegex = Regex("(?i)BYN|руб\\.?|₽|RUB|USD|EUR|€|\\$")
    private val amountWithCurrencyRegex = Regex("(${amountRegex.pattern})\\s*($currencyRegex.pattern)")
    private val labelAmountRegex = Regex(
        "(?i)(?:баланс|доступно|остаток)\\D{0,20}?(${amountRegex.pattern})\\s*($currencyRegex.pattern)"
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        hidePanel()
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    override fun onInterrupt() = Unit

    // ---------- Panel UI ----------

    fun showPanel() {
        if (panelView != null) return
        handler.post { buildPanel() }
    }

    fun hidePanel() {
        panelView?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        panelView = null
        panelMode = PanelMode.NONE
    }

    private fun panelLog(message: String) {
        DebugLog.log(message)
        panelLines.addLast(message)
        while (panelLines.size > 6) panelLines.removeFirst()
        panelLogsView?.text = panelLines.joinToString("\n")
    }

    private fun setStatus(text: String) {
        panelStatus?.text = text
    }

    private fun button(text: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.textSize = 13f
        b.setAllCaps(false)
        b.isClickable = true
        b.setOnClickListener { try { action() } catch (e: Exception) { panelLog("Ошибка: ${e.message}") } }
        return b
    }

    private fun buildPanel() {
        if (panelView != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(28, 20, 28, 24)
        box.background = GradientDrawable().apply {
            setColor(Color.argb(238, 18, 18, 22))
            cornerRadius = 28f
        }

        val drag = TextView(this)
        drag.text = "☰ Payment Helper — панель"
        drag.setTextColor(Color.WHITE)
        drag.textSize = 15f
        drag.typeface = Typeface.DEFAULT_BOLD
        drag.setPadding(0, 0, 0, 14)
        box.addView(drag)

        val status = TextView(this)
        status.setTextColor(Color.rgb(150, 220, 150))
        status.textSize = 13f
        status.text = "Панель открыта. Начните с «Обучить пин-код»."
        box.addView(status)
        panelStatus = status

        val logs = TextView(this)
        logs.setTextColor(Color.LTGRAY)
        logs.textSize = 11f
        logs.typeface = Typeface.MONOSPACE
        logs.setPadding(0, 10, 0, 10)
        box.addView(logs)
        panelLogsView = logs

        box.addView(button("1. Обучить пин-код (счётчик 1..5)") { startPinLearning() })
        box.addView(button("2. Запомнить кнопку обновления") { startRefreshLearningPanel() })
        box.addView(button("3. Войти самостоятельно (пин + обновление)") { autoRun() })
        box.addView(button("Сбросить пин") { clearLearned(applicationContext); panelLog("Пин сброшен."); setStatus("Пин сброшен.") })
        box.addView(button("Сбросить кнопку обновления") { clearRefresh(applicationContext); panelLog("Кнопка обновления сброшена.") })
        box.addView(button("Скрыть панель") { hidePanel() })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 24
        params.y = 120

        // drag by the title
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var dragging = false
        drag.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startX = params.x; startY = params.y; dragging = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX; val dy = ev.rawY - downY
                    if (dragging || Math.abs(dx) > 12 || Math.abs(dy) > 12) {
                        dragging = true
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        try { wm.updateViewLayout(box, params) } catch (_: Exception) {}
                    }
                    true
                }
                else -> false
            }
        }

        wm.addView(box, params)
        panelView = box
        panelLogsView?.text = panelLines.joinToString("\n")
    }

    // ---------- Panel actions ----------

    private fun startPinLearning() {
        pinDraft = StringBuilder()
        pinCount = 0
        panelMode = PanelMode.LEARN_PIN
        setStatus("Введите пин-код в банке — считаю нажатия…")
        panelLog("Обучение пина: вводите пин-код в банке.")
    }

    private fun startRefreshLearningPanel() {
        panelMode = PanelMode.LEARN_REFRESH
        setStatus("Нажмите на кнопку обновления баланса в банке.")
        panelLog("Теперь нажмите на кнопку обновления — запомню её.")
    }

    private fun autoRun() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val pkg = prefs.getString("selected_package", null)
        val steps = loadSteps(this)
        if (pkg == null) { setStatus("Сначала выберите приложение в Payment Helper."); return }
        if (steps.size < PIN_LENGTH) { setStatus("Сначала обучите пин-код (кнопка 1)."); return }
        if (!isRefreshLearned(this)) { setStatus("Сначала запомните кнопку обновления (кнопка 2)."); return }
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) { setStatus("Не удалось открыть банк."); return }
        panelMode = PanelMode.NONE
        autoRunning = true
        savedSteps = steps
        setStatus("Открываю банк…")
        panelLog("Авто-режим: открываю банк, ввод пина через 6 секунд.")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        savedSteps.forEachIndexed { index, (x, y) ->
            handler.postDelayed({
                panelLog("Счётчик: ${index + 1} из ${savedSteps.size}")
                tapAt(x, y) { }
            }, AUTO_OPEN_DELAY_MS + index * TAP_INTERVAL_MS)
        }
        handler.postDelayed({
            panelLog("Пин-код введён. Нажимаю обновление баланса…")
            tapAt(prefs.getFloat("refresh_x", 0f), prefs.getFloat("refresh_y", 0f)) { }
        }, AUTO_OPEN_DELAY_MS + savedSteps.size * TAP_INTERVAL_MS + SETTLE_AFTER_LAST_TAP_MS)
        handler.postDelayed({ readBalance() },
            AUTO_OPEN_DELAY_MS + savedSteps.size * TAP_INTERVAL_MS + SETTLE_AFTER_LAST_TAP_MS + BALANCE_READ_AFTER_TAP_MS)
    }

    // ---------- Events ----------

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED) return
        val node = event.source ?: return
        val rect = Rect()
        node.getBoundsInScreen(rect)
        if (rect.isEmpty) return

        // Panel: pin learning
        if (panelMode == PanelMode.LEARN_PIN) {
            val label = node.text?.toString()?.trim().orEmpty()
            if (digitRegex.matches(label)) {
                pinCount++
                if (pinDraft.isNotEmpty()) pinDraft.append(";")
                pinDraft.append(rect.exactCenterX().toInt()).append(",").append(rect.exactCenterY().toInt())
                if (pinCount >= PIN_LENGTH) {
                    getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putString("pin_steps", pinDraft.toString()).apply()
                    savedSteps = loadSteps(this)
                    panelMode = PanelMode.LEARN_REFRESH
                    panelLog("Счётчик: $pinCount — идеально! Пин запомнил.")
                    setStatus("Теперь нажмите на кнопку обновления баланса.")
                    panelLog("Нажмите на кнопку обновления — запомню её.")
                } else {
                    panelLog("Счётчик: $pinCount")
                    setStatus("Введено цифр: $pinCount из $PIN_LENGTH")
                }
            }
            return
        }

        // Panel: refresh button learning
        if (panelMode == PanelMode.LEARN_REFRESH && !autoRunning) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putFloat("refresh_x", rect.exactCenterX())
                .putFloat("refresh_y", rect.exactCenterY())
                .apply()
            panelMode = PanelMode.NONE
            setStatus("Кнопка обновления запомнена. Можно жать «Войти самостоятельно».")
            panelLog("Кнопка обновления запомнена.")
            return
        }

        // Old flow: refresh learning from the app screen
        if (learningRefresh) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putFloat("refresh_x", rect.exactCenterX())
                .putFloat("refresh_y", rect.exactCenterY())
                .apply()
            learningRefresh = false
            DebugLog.log("Кнопка обновления запомнена.")
            return
        }

        // Old flow: pin learning taps
        val pkg = event.packageName?.toString() ?: return
        if (loginStartedAt != 0L && learnMode && pkg == loginPackage) {
            val label = node.text?.toString()?.trim().orEmpty()
            if (digitRegex.matches(label)) {
                val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val current = prefs.getString("pin_draft", "") ?: ""
                val updated = if (current.isEmpty()) "${rect.exactCenterX()},${rect.exactCenterY()}"
                    else "$current;${rect.exactCenterX()},${rect.exactCenterY()}"
                prefs.edit().putString("pin_draft", updated).apply()
                val count = updated.split(";").size
                DebugLog.log("Запомнено нажатие №$count.")
                if (count >= PIN_LENGTH) {
                    prefs.edit().putString("pin_steps", updated).remove("pin_draft").apply()
                    savedSteps = loadSteps(this)
                    learnMode = false
                    publishResult("Пин-код запомнен ($count нажатий). Дальше справлюсь сам!")
                }
            }
        }
    }

    // ---------- Tick state machines ----------

    @Volatile private var learningRefresh = false

    private fun onTick() {
        if (autoRunning) return

        if (loginStartedAt == 0L) return
        val bank = loginPackage ?: return
        val now = SystemClock.elapsedRealtime()

        if (now - loginStartedAt > LOGIN_WINDOW_MS) {
            publishResult("Время вышло, вход не подтверждён. Попробуйте ещё раз.")
            return
        }

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != bank) return

        val texts = mutableListOf<String>()
        collectVisibleText(root, texts, 0)
        val screenText = texts.joinToString(" ")

        if (awaitingResult) {
            when {
                looksLikeLoggedInHome(screenText) -> publishResult("Красава, вход выполнен!")
                errorRegex.containsMatchIn(screenText) ->
                    publishResult("Вход не выполнен: банк сообщил об ошибке. Проверьте пин-код.")
            }
            return
        }

        if (learnMode) {
            if (!manualHintShown) {
                manualHintShown = true
                DebugLog.log("Жду ваш пин-код: просто введите его на клавиатуре банка.")
            }
        } else if (!replayInFlight) {
            replayPin()
        }
    }

    // ---------- Balance reading ----------

    private fun readBalance() {
        val root = rootInActiveWindow
        if (root != null) {
            val texts = mutableListOf<String>()
            collectVisibleText(root, texts, 0)
            extractBalance(texts)?.let { value ->
                publishBalance(this, "Баланс получен: $value", value)
                panelLog("Баланс: $value")
                setStatus("Баланс: $value")
                autoRunning = false
                return
            }
            panelLog("В тексте сумму не нашёл, пробую скриншот + OCR…")
        }
        takeScreenshotAndRead()
    }

    private fun extractBalance(texts: List<String>): String? {
        val joined = texts.joinToString(" | ")
        labelAmountRegex.find(joined)?.let {
            return clean(it.groupValues[1] + " " + it.groupValues[2])
        }
        for (i in texts.indices) {
            amountWithCurrencyRegex.find(texts[i])?.let {
                return clean(it.groupValues[1] + " " + it.groupValues[2])
            }
        }
        amountWithCurrencyRegex.find(joined)?.let {
            return clean(it.groupValues[1] + " " + it.groupValues[2])
        }
        return null
    }

    private fun takeScreenshotAndRead() {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.R) {
            publishBalance(this, "Баланс не найден: нужен Android 11+ для скриншота.", null)
            setStatus("Нужен Android 11+ для скриншота.")
            autoRunning = false
            return
        }
        takeScreenshot(android.view.Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                try {
                    val hardwareBuffer = screenshot.hardwareBuffer
                    val bitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, screenshot.colorSpace)
                    hardwareBuffer.close()
                    if (bitmap == null) {
                        publishBalance(applicationContext, "Скриншот не удался.", null)
                        autoRunning = false
                        return
                    }
                    runOcr(bitmap.copy(Bitmap.Config.ARGB_8888, false))
                } catch (e: Exception) {
                    publishBalance(applicationContext, "Ошибка скриншота: ${e.message}", null)
                    autoRunning = false
                }
            }
            override fun onFailure(errorCode: Int) {
                publishBalance(applicationContext, "Скриншот запрещён системой (код $errorCode).", null)
                autoRunning = false
            }
        })
    }

    private fun runOcr(bitmap: Bitmap) {
        try {
            val image = com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap, 0)
            val recognizer = com.google.mlkit.vision.text.TextRecognition.getClient(
                com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS
            )
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val lines = visionText.text.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
                    DebugLog.log("OCR увидел: ${lines.take(12).joinToString(" | ")}")
                    val found = extractBalance(lines)
                    recognizer.close()
                    if (found != null) {
                        publishBalance(applicationContext, "Баланс получен (по скриншоту): $found", found)
                        panelLog("Обновила. Баланс: $found")
                        setStatus("Баланс: $found")
                    } else {
                        publishBalance(applicationContext, "Баланс не распознан. Убедитесь, что сумма видна на экране.", null)
                        panelLog("OCR сумму не нашёл.")
                        setStatus("Баланс не распознан — сумма должна быть видна на экране.")
                    }
                    autoRunning = false
                }
                .addOnFailureListener { e ->
                    recognizer.close()
                    publishBalance(applicationContext, "OCR не сработал: ${e.message}", null)
                    setStatus("OCR не сработал: ${e.message}")
                    autoRunning = false
                }
        } catch (e: Exception) {
            publishBalance(applicationContext, "Ошибка OCR: ${e.message}", null)
            setStatus("Ошибка OCR: ${e.message}")
            autoRunning = false
        }
    }

    // ---------- Old-flow helpers ----------

    private fun returnToApp() {
        val back = packageManager.getLaunchIntentForPackage(applicationContext.packageName)
        if (back != null) {
            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(back)
        }
    }

    private fun replayPin() {
        if (savedSteps.isEmpty()) return
        replayInFlight = true
        DebugLog.log("Начинаю ввод пин-кода через 7 секунд…")
        val startDelayMs = 7_000L
        savedSteps.forEachIndexed { index, (x, y) ->
            handler.postDelayed({
                DebugLog.log("Нажимаю цифру ${index + 1} из ${savedSteps.size}…")
                tapAt(x, y) { }
            }, startDelayMs + index * TAP_INTERVAL_MS)
        }
        handler.postDelayed({
            awaitingResult = true
            replayInFlight = false
        }, startDelayMs + savedSteps.size * TAP_INTERVAL_MS + SETTLE_AFTER_LAST_TAP_MS)
    }

    private fun tapAt(x: Float, y: Float, callback: (Boolean) -> Unit) {
        val path = android.graphics.Path().apply { moveTo(x, y) }
        val gesture = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0L, 60L))
            .build()
        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: android.accessibilityservice.GestureDescription?) = callback(true)
            override fun onCancelled(g: android.accessibilityservice.GestureDescription?) {
                DebugLog.log("Нажатие отменено системой.")
                callback(false)
            }
        }, null)
        if (!dispatched) callback(false)
    }

    private fun looksLikeLoggedInHome(allText: String): Boolean {
        val all = allText.lowercase()
        if (loginScreenRegex.containsMatchIn(all)) return false
        return homeWords.count { it in all } >= 2
    }

    private fun publishResult(message: String) {
        loginStartedAt = 0L
        awaitingResult = false
        loginPackage = null
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("pin_draft").apply()
        DebugLog.log(message)
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit()
            .putString("login_result", message)
            .putLong("login_result_time", System.currentTimeMillis())
            .apply()
        val back = prefs.getString("login_package", null)?.let { packageManager.getLaunchIntentForPackage(it) }
        if (back != null) {
            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(back)
        }
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size > 500) return
        if (node.isVisibleToUser) {
            node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        }
        for (i in 0 until node.childCount) collectVisibleText(node.getChild(i), out, depth + 1)
    }

    private fun clean(s: String): String = s.replace(Regex("[\\s\\u00A0]+"), " ").trim()
}
