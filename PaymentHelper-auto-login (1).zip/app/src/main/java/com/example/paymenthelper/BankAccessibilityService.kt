package com.example.paymenthelper

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Automates a single login attempt in the selected bank app:
 * fills the stored password into the login field, taps the submit button,
 * then watches the screen for success (home screen) or an error message.
 *
 * Robustness notes (why it stopped "misbehaving" on the second run):
 * - onAccessibilityEvent does no heavy work; all periodic attempts are driven
 *   by a lightweight 1-second handler tick, so a flood of accessibility
 *   events (or their absence) can neither block the service nor stall the flow.
 * - Every callback body is wrapped in try/catch and logged; an uncaught
 *   exception inside an accessibility service is what makes Android show
 *   "service is not responding — turn it off and on".
 *
 * The login screen may take several seconds to appear; the tick keeps retrying
 * the fill step (every ~1 s) until the window expires, so a 5-second splash is
 * not a problem.
 */
class BankAccessibilityService : AccessibilityService() {

    companion object {
        private const val PREFS = "payment_helper"
        private const val LOGIN_WINDOW_MS = 120_000L
        private const val TICK_MS = 1_000L          // periodic retry interval
        private const val RESULT_GRACE_MS = 1_500L  // settle time after submit
        private const val MAX_DEPTH = 30

        @Volatile private var loginStartedAt: Long = 0L
        @Volatile private var loginPackage: String? = null
        @Volatile private var loginFinished: Boolean = false
        @Volatile private var submitPressedAt: Long = 0L
        @Volatile private var awaitingResult: Boolean = false
        @Volatile private var lastFillLog: String = ""

        fun beginLoginCheck(context: Context, packageName: String) {
            loginStartedAt = SystemClock.elapsedRealtime()
            loginPackage = packageName
            loginFinished = false
            submitPressedAt = 0L
            awaitingResult = false
            lastFillLog = ""
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("login_package", packageName)
                .putLong("login_started_at", System.currentTimeMillis())
                .putLong("login_result_time", 0L)
                .apply()
            DebugLog.log("SVC: beginLoginCheck пакет=$packageName")
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            try {
                onTick()
            } catch (e: Exception) {
                DebugLog.log("SVC: ОШИБКА в тике — ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                handler.postDelayed(this, TICK_MS)
            }
        }
    }

    private val loginScreenRegex = Regex("(?i)войти|пароль|логин|sign in|log in|passcode|password|введите")
    private val submitRegex = Regex("(?i)^\\s*(войти|вход|подтвердить|sign in|log in|login|далее|next)\\s*$")
    private val errorRegex = Regex(
        "(?i)неверн|неправильн|ошибк|не удалось войти|повторите попытку|заблокирован|incorrect|wrong password|invalid|try again"
    )
    private val homeWords = listOf(
        "карты", "счета", "переводы", "платежи", "история", "баланс",
        "профиль", "accounts", "cards", "transfers", "payments", "history"
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        DebugLog.log("SVC: служба подключена")
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        DebugLog.log("SVC: служба уничтожена")
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally minimal: the heavy lifting happens in onTick().
        // Logging only the essential bits to avoid log flooding from chatty apps.
        if (event == null || loginFinished || loginStartedAt == 0L) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            DebugLog.log("SVC: окно изменено, пакет=${event.packageName}")
        }
    }

    override fun onInterrupt() {
        DebugLog.log("SVC: onInterrupt")
    }

    /** Called every second; drives the whole fill → result state machine. */
    private fun onTick() {
        if (loginFinished || loginStartedAt == 0L) return
        val bank = loginPackage ?: return
        val now = SystemClock.elapsedRealtime()

        if (now - loginStartedAt > LOGIN_WINDOW_MS) {
            publishResult("Не удалось подтвердить вход автоматически ($lastFillLog). Вернитесь и попробуйте ещё раз.")
            return
        }

        val root = rootInActiveWindow ?: run {
            DebugLog.log("SVC: тик — активное окно недоступно")
            return
        }
        val pkg = root.packageName?.toString()
        if (pkg != bank) {
            // The bank is not in the foreground (splash of launcher etc.) — wait.
            DebugLog.log("SVC: тик — на переднем плане $pkg, ждём $bank")
            return
        }

        val texts = mutableListOf<String>()
        collectVisibleText(root, texts, 0)
        val screenText = texts.joinToString(" ")
        DebugLog.log("SVC: тик — экран: ${screenText.take(120)}")

        if (!awaitingResult) {
            if (!loginScreenRegex.containsMatchIn(screenText)) {
                lastFillLog = "экран входа не распознан"
                DebugLog.log("SVC: тик — экран входа пока не распознан")
                return
            }
            attemptFill(root)
        } else {
            if (now - submitPressedAt < RESULT_GRACE_MS) return
            when {
                looksLikeLoggedInHome(screenText) -> {
                    DebugLog.log("SVC: обнаружен главный экран — успех")
                    publishResult("Красава, вход выполнен!")
                }
                errorRegex.containsMatchIn(screenText) -> {
                    DebugLog.log("SVC: обнаружено сообщение об ошибке на экране")
                    publishResult("Вход не выполнен: приложение сообщило об ошибке (проверьте пароль).")
                }
                else -> DebugLog.log("SVC: тик — ждем результат входа…")
            }
        }
    }

    private fun attemptFill(root: AccessibilityNodeInfo) {
        val editables = collectEditables(root, 0)
        if (editables.isEmpty()) {
            lastFillLog = "поле ввода не найдено"
            DebugLog.log("SVC: заполение — редактируемых полей на экране нет")
            return
        }
        editables.forEachIndexed { i, n ->
            DebugLog.log(
                "SVC: поле[$i] class=${n.className} hint=\"${n.hintText}\" " +
                    "text=\"${n.text}\""  // по соображениям безопасности текст поля не логируем полностью
            )
        }
        val target = editables.last() // последнее поле обычно и есть ввод пароля
        val password = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("login_password", "olga123") ?: "olga123"

        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, password)
        }
        val setTextOk = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        DebugLog.log("SVC: заполнение поля (длина пароля=${password.length}) → ACTION_SET_TEXT=$setTextOk")
        if (!setTextOk) {
            lastFillLog = "поле не приняло текст"
            return
        }

        val button = findSubmitButton(root, 0)
        if (button == null) {
            lastFillLog = "кнопка «Войти» не найдена"
            DebugLog.log("SVC: кнопка «Войти» не найдена, тексты экрана: ${screenTextOf(root).take(200)}")
            return
        }
        val clicked = button.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        DebugLog.log("SVC: нажатие кнопки → ACTION_CLICK=$clicked")
        if (clicked) {
            awaitingResult = true
            submitPressedAt = SystemClock.elapsedRealtime()
            lastFillLog = "кнопка нажата"
        } else {
            lastFillLog = "клик по кнопке не сработал"
        }
    }

    private fun collectEditables(node: AccessibilityNodeInfo?, depth: Int): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        collectEditablesRec(node, depth, out)
        return out
    }

    private fun collectEditablesRec(node: AccessibilityNodeInfo?, depth: Int, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null || depth > MAX_DEPTH || out.size > 10) return
        val editableLike = (node.isEditable || node.hintText != null) && node.isVisibleToUser
        if (editableLike) {
            DebugLog.log("SVC: найдено поле ввода: class=${node.className} hint=\"${node.hintText}\"")
            out.add(node)
        }
        for (i in 0 until node.childCount) {
            collectEditablesRec(node.getChild(i), depth + 1, out)
        }
    }

    private fun findSubmitButton(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > MAX_DEPTH) return null
        val label = node.text?.toString().orEmpty().ifEmpty {
            node.contentDescription?.toString().orEmpty()
        }
        if (label.isNotEmpty() && submitRegex.containsMatchIn(label)) {
            DebugLog.log("SVC: кандидат на кнопку: \"$label\" class=${node.className}")
            var current: AccessibilityNodeInfo? = node
            var hops = 0
            while (current != null && hops < 5) {
                if (current.isClickable) {
                    DebugLog.log("SVC: кликабельный предок найден (hops=$hops)")
                    return current
                }
                current = current.parent
                hops++
            }
            DebugLog.log("SVC: у кандидата \"$label\" нет кликабельных предков")
        }
        for (i in 0 until node.childCount) {
            findSubmitButton(node.getChild(i), depth + 1)?.let { return it }
        }
        return null
    }

    private fun looksLikeLoggedInHome(allText: String): Boolean {
        val all = allText.lowercase()
        if (loginScreenRegex.containsMatchIn(all)) return false
        val matched = homeWords.filter { it in all }
        if (matched.size >= 2) DebugLog.log("SVC: признаки главного экрана: $matched")
        return matched.size >= 2
    }

    private fun publishResult(message: String) {
        loginFinished = true
        loginStartedAt = 0L
        awaitingResult = false
        val pkg = loginPackage
        loginPackage = null
        DebugLog.log("SVC: итог — $message")
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("login_result", message)
            .putLong("login_result_time", System.currentTimeMillis())
            .apply()
        val back = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        if (back != null) {
            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(back)
            DebugLog.log("SVC: возврат в Payment Helper")
        } else {
            DebugLog.log("SVC: не удалось построить intent возврата")
        }
    }

    private fun screenTextOf(root: AccessibilityNodeInfo): String {
        val texts = mutableListOf<String>()
        collectVisibleText(root, texts, 0)
        return texts.joinToString(" ")
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size > 500) return
        if (node.isVisibleToUser) {
            node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        }
        for (i in 0 until node.childCount) collectVisibleText(node.getChild(i), out, depth + 1)
    }
}
