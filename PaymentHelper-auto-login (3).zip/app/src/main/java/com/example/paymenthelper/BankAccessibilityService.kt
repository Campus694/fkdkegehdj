package com.example.paymenthelper

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Two-mode login automation.
 *
 * LEARNING RUN (first time, or after the user resets): the user logs in
 * manually; the service observes their taps and remembers the screen
 * coordinates of the input field and the «Войти» button.
 *
 * AUTO RUN (every next time): taps the remembered field, pastes the password
 * from the clipboard (put there by MainActivity while in the foreground),
 * then taps the remembered «Войти» button, and reports the result.
 */
class BankAccessibilityService : AccessibilityService() {

    companion object {
        private const val PREFS = "payment_helper"
        private const val LOGIN_WINDOW_MS = 150_000L
        private const val TAP_FIELD_TO_PASTE_MS = 800L
        private const val PASTE_TO_BUTTON_MS = 600L

        @Volatile private var loginStartedAt: Long = 0L
        @Volatile private var loginPackage: String? = null
        @Volatile private var awaitingResult: Boolean = false
        @Volatile private var fillInFlight: Boolean = false
        private var manualHintShown = false

        fun beginLoginCheck(context: Context, packageName: String) {
            loginStartedAt = SystemClock.elapsedRealtime()
            loginPackage = packageName
            awaitingResult = false
            fillInFlight = false
            manualHintShown = false
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("login_package", packageName)
                .putLong("login_started_at", System.currentTimeMillis())
                .putLong("login_result_time", 0L)
                .apply()
            val learned = isLearned(context)
            DebugLog.log(
                if (learned) "Вход запускается автоматически по сохранённым координатам."
                else "Первый запуск: войдите вручную — я запомню, где поле и кнопка «Войти»."
            )
        }

        private fun isLearned(context: Context): Boolean =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .contains("field_x")

        fun clearLearned(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove("field_x").remove("field_y")
                .remove("button_x").remove("button_y")
                .apply()
            DebugLog.log("Сохранённые координаты сброшены.")
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            try { onTick() } catch (e: Exception) {
                DebugLog.log("Ошибка сервиса: ${e.message}")
            } finally {
                handler.postDelayed(this, 1_000L)
            }
        }
    }

    private val loginScreenRegex = Regex("(?i)войти|пароль|ключ|введите|sign in|log in|password")
    private val submitRegex = Regex("(?i)^\\s*(войти|вход|подтвердить|sign in|log in|login|далее|next)\\s*$")
    private val errorRegex = Regex(
        "(?i)неверн|неправильн|ошибк|не удалось войти|повторите попытку|заблокирован|incorrect|wrong password|invalid|try again"
    )
    private val homeWords = listOf(
        "карты", "счета", "переводы", "платежи", "история", "баланс",
        "профиль", "accounts", "cards", "transfers", "payments", "history"
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || loginStartedAt == 0L || awaitingResult) return
        val bank = loginPackage ?: return
        if (event.packageName?.toString() != bank) return

        // Learning: the user taps the field and the button manually — remember them.
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            val node = event.source ?: return
            val label = node.text?.toString().orEmpty().ifEmpty { node.hintText?.toString().orEmpty() }
            val rect = android.graphics.Rect()
            node.getBoundsInScreen(rect)
            if (rect.isEmpty) return

            val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (submitRegex.containsMatchIn(label)) {
                prefs.edit().putFloat("button_x", rect.exactCenterX())
                    .putFloat("button_y", rect.exactCenterY()).apply()
                DebugLog.log("Кнопка «Войти» запомнена.")
                if (!isLearned(this)) awaitingResult = true // user is logging in right now
            } else if (node.isEditable || node.hintText != null ||
                label.contains("введите", true) || label.contains("ключ", true)) {
                prefs.edit().putFloat("field_x", rect.exactCenterX())
                    .putFloat("field_y", rect.exactCenterY()).apply()
                DebugLog.log("Поле ввода запомнено.")
            }
        }
    }

    override fun onInterrupt() = Unit

    private fun onTick() {
        if (loginStartedAt == 0L) return
        val bank = loginPackage ?: return
        val now = SystemClock.elapsedRealtime()

        if (now - loginStartedAt > LOGIN_WINDOW_MS) {
            publishResult("Время вышло, вход не подтверждён. Попробуйте ещё раз.")
            return
        }

        if (awaitingResult) {
            val root = rootInActiveWindow ?: return
            if (root.packageName?.toString() != bank) return
            val texts = mutableListOf<String>()
            collectVisibleText(root, texts, 0)
            val screenText = texts.joinToString(" ")
            when {
                looksLikeLoggedInHome(screenText) -> publishResult("Красава, вход выполнен!")
                errorRegex.containsMatchIn(screenText) ->
                    publishResult("Вход не выполнен: банк сообщил об ошибке. Проверьте пароль.")
            }
            return
        }

        if (isLearned(this)) {
            if (!fillInFlight) autoFillAndSubmit()
        } else if (!manualHintShown) {
            manualHintShown = true
            DebugLog.log("Жду вашего входа: нажмите поле, введите код и нажмите «Войти».")
        }
    }

    /** AUTO RUN: tap field → paste password → tap «Войти». */
    private fun autoFillAndSubmit() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val fx = prefs.getFloat("field_x", -1f)
        val fy = prefs.getFloat("field_y", -1f)
        val bx = prefs.getFloat("button_x", -1f)
        val by = prefs.getFloat("button_y", -1f)
        if (fx < 0 || fy < 0 || bx < 0 || by < 0) return

        fillInFlight = true
        DebugLog.log("Ввожу пароль автоматически…")
        tapAt(fx, fy) { tapped ->
            handler.postDelayed({
                try {
                    if (tapped) pasteIntoFocused()
                    DebugLog.log("Нажимаю «Войти»…")
                    tapAt(bx, by) { }
                    awaitingResult = true
                } finally {
                    fillInFlight = false
                }
            }, TAP_FIELD_TO_PASTE_MS)
        }
    }

    private fun pasteIntoFocused() {
        val focused = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused == null) {
            DebugLog.log("Поле не в фокусе, вставка пропущена.")
            return
        }
        val ok = focused.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        DebugLog.log(if (ok) "Пароль вставлен." else "Вставка не сработала, пробую нажать «Войти».")
    }

    private fun tapAt(x: Float, y: Float, callback: (Boolean) -> Unit) {
        val path = android.graphics.Path().apply { moveTo(x, y) }
        val gesture = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0L, 60L))
            .build()
        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: android.accessibilityservice.GestureDescription?) = callback(true)
            override fun onCancelled(g: android.accessibilityservice.GestureDescription?) {
                DebugLog.log("Нажатие отменено системой.")
                callback(false)
            }
        }, null)
        if (!dispatched) callback(false)
    }

    private fun looksLikeLoggedInHome(allText: String): Boolean {
        val all = allText.lowercase()
        if (loginScreenRegex.containsMatchIn(all)) return false
        return homeWords.count { it in all } >= 2
    }

    private fun publishResult(message: String) {
        loginStartedAt = 0L
        awaitingResult = false
        loginPackage = null
        DebugLog.log(message)
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit()
            .putString("login_result", message)
            .putLong("login_result_time", System.currentTimeMillis())
            .apply()
        val back = prefs.getString("login_package", null)?.let { packageManager.getLaunchIntentForPackage(it) }
        if (back != null) {
            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(back)
        }
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 25 || out.size > 500) return
        if (node.isVisibleToUser) {
            node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(out::add)
        }
        for (i in 0 until node.childCount) collectVisibleText(node.getChild(i), out, depth + 1)
    }
}
